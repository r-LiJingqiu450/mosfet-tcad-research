# -*- coding: utf-8 -*-
"""
第三阶段 MOSFET 直流仿真主驱动：构建表格 → 扫描 → 参数提取 → 验证清单。

    系列化说明：run() 返回 dict 含四标准键（params/results/validation/
    defects，见 docs/spec/code_spec.md）；其余键为历史平铺结果。

用法：cd mosfet && python run.py
"""

import time
import warnings

import numpy as np

from common import constants as C
from common.grid import make_surface_grid, make_channel_grid, grid_stats
from common.validation import (Checklist, VALIDATION, SELF_CHECK,
                               FORMAT_CHECK, ARTIFACT)
from .table import SliceTable
from .gca import (gca_solve, id_vg, id_vd, transfer_characteristics,
                  output_characteristics)
from . import postprocess as pp

STAGE3_DEFECTS = ["DEF-S3-01", "DEF-S3-02", "DEF-S3-03", "DEF-S3-04",
                  "DEF-S3-05"]


# ================================================================================
# 默认表格与网格
# ================================================================================

def default_x_grid(d0=0.125e-9, h_max=4.0e-9, x_max=1.2e-6):
    """
    生产纵向网格。d0=0.125 nm：反型层衰减长度 V_T/E_s ~ 4-5 nm，
    而表面势误差被 N_s 的 1/V_T 敏感度放大，d0 收敛呈干净二阶
    （1.0/0.5/0.25/0.125 nm -> I_D 偏差 11.7%/3.0%/0.9%/0.2%，
    Richardson 极限误差 ~0.02%）。h_max=4 nm 覆盖耗尽层与体区。
    """
    return make_surface_grid(x_max, d0=d0, h_max=h_max)


def default_table(x=None, phi_s_n=240, phi_n_n=110):
    if x is None:
        x = default_x_grid()
    phi_s_grid = np.linspace(-0.3, 1.6, phi_s_n)
    phi_n_grid = np.linspace(0.0, 2.0, phi_n_n)
    return SliceTable(phi_s_grid, phi_n_grid, x)


# ================================================================================
# 主流程
# ================================================================================

def run(verbose=True, vg_max=2.0, vd_max=2.0):
    t_start = time.time()
    x = default_x_grid()
    if verbose:
        print("=" * 72)
        print("第三阶段：1D 纵向 Poisson + 准二维 GCA 的 MOSFET 直流仿真")
        print("=" * 72)
        print(f"[器件] Na={C.NA_CM3:.0e} cm^-3, tox={C.TOX_NM:.0f} nm, "
              f"L={C.L_CH * 1e6:.1f} um, W={C.W_CH * 1e6:.1f} um, "
              f"VFB={C.VFB:.2f} V")
        print(f"[网格] {grid_stats(x)}")
        print(f"[解析] psi_F={C.PSI_F:.4f} V, 2*psi_F={C.TWICE_PSI_F:.4f} V, "
              f"VT_long={C.VT_LONG:.4f} V, gamma={C.GAMMA:.4f} V^0.5")

    # ---- 1. 构建表格 ----
    t0 = time.time()
    tab = default_table(x)
    tab.build()
    t_table = time.time() - t0
    if verbose:
        print(f"[表格] ({tab.nps} x {tab.npn}) 构建耗时 {t_table:.1f} s")

    # ---- 2. 转移特性 I_D-V_G ----
    vg_list = np.linspace(0.0, vg_max, 81)
    tr = transfer_characteristics(tab, vg_list, vd_lin=0.05, vd_sat=1.5)
    id_lin, id_sat = tr["id_lin"], tr["id_sat"]

    # ---- 3. 参数提取 ----
    vt_cc, i_th = pp.extract_vt(vg_list, id_lin)
    ss_lin = pp.extract_ss(vg_list, id_lin)
    ss_sat = pp.extract_ss(vg_list, id_sat)
    gm, gm_max = pp.extract_gm(vg_list, id_sat)
    ss_loc = pp.local_ss(vg_list, id_lin)
    sub = (vg_list > 0.5) & (vg_list < vt_cc)
    ss_min = float(np.nanmin(ss_loc[sub]))
    ss_th_min = float(np.log(10) * C.VT * (
        1 + C.EPS_SI / (np.sqrt(2 * C.EPS_SI * C.TWICE_PSI_F /
                                (C.Q_E * C.NA)) * C.COX)) * 1000)

    if verbose:
        print("\n[参数提取]")
        print(f"  V_T(恒定电流 {i_th * 1e6:.2f} uA) = {vt_cc:.4f} V "
              f"(解析 {C.VT_LONG:.4f} V)")
        print(f"  SS(线性区 V_D=0.05, 固定窗口) = {ss_lin:.1f} mV/dec")
        print(f"  SS(饱和区 V_D=1.5, 固定窗口)  = {ss_sat:.1f} mV/dec")
        print(f"  SS 局部最小值(近阈值) = {ss_min:.1f} mV/dec, "
              f"衬偏效应理论 = {ss_th_min:.1f} mV/dec")
        print(f"  g_m,max = {gm_max:.4e} S")

    # ---- 4. Square-law 对照（仅强反型段 V_G > V_T + 0.2，避开亚阈值区）----
    def rel_dev(a, b, vg_arr, vt):
        a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
        vg_arr = np.asarray(vg_arr, dtype=float)
        mask = (vg_arr > vt + 0.2) & np.isfinite(a) & np.isfinite(b) & (b > 0)
        if mask.sum() == 0:
            return float("nan"), float("nan")
        dev = (a[mask] - b[mask]) / b[mask] * 100
        i = int(np.argmax(np.abs(dev)))
        return float(dev[i]), float(vg_arr[mask][i])

    sq_lin_analytic = C.square_law_id(vg_list, 0.05)
    sq_lin_fit = square_law_id_vt(vg_list, 0.05, vt_cc)
    sq_sat_fit = square_law_id_vt(vg_list, 1.5, vt_cc)

    dev_lin_analytic = rel_dev(id_lin, sq_lin_analytic, vg_list, C.VT_LONG)[0]
    dev_lin_fit, vg_dev_lin = rel_dev(id_lin, sq_lin_fit, vg_list, vt_cc)
    dev_sat_fit, vg_dev_sat = rel_dev(id_sat, sq_sat_fit, vg_list, vt_cc)

    if verbose:
        print("\n[Square-law 对照]")
        print(f"  线性区 (V_D=0.05, 强反型段) 对解析 V_T 最大偏差 = "
              f"{dev_lin_analytic:.1f} %")
        print(f"  线性区 对提取 V_T({vt_cc:.3f}) 最大偏差 = {dev_lin_fit:.1f} % "
              f"@ V_G={vg_dev_lin:.2f} V")
        print(f"  线性区 V_G=2.0 处偏差 = "
              f"{(id_lin[-1]-sq_lin_fit[-1])/sq_lin_fit[-1]*100:.1f} %")
        print(f"  饱和区 (V_D=1.5) 对提取 V_T 最大偏差 = {dev_sat_fit:.1f} % "
              f"@ V_G={vg_dev_sat:.2f} V")

    # ---- 5. 输出特性 I_D-V_D ----
    vd_list = np.linspace(0.0, vd_max, 61)
    vg_curves = [1.2, 1.5, 2.0]
    out = output_characteristics(tab, vg_curves, vd_list)
    # 夹断点移动（V_G=2.0）
    _, _, yps = id_vd(tab, 2.0, vd_list)
    if verbose:
        print("\n[输出特性与夹断]")
        for i, vg in enumerate(vg_curves):
            print(f"  V_G={vg:.1f} V: 饱和电流 I_D(V_D={vd_max:.1f}) = "
                  f"{out['ids'][i, -1]:.4e} A")
        print(f"  V_G=2.0 夹断点 y_p: V_D=1.0 -> {yps[np.argmin(abs(vd_list-1.0))]*1e9:.0f} nm, "
              f"V_D=2.0 -> {yps[-1]*1e9:.0f} nm（向源端移动）")

    # ---- 6. 电流连续性校验 ----
    conts = []
    for vg, vd in [(1.5, 0.05), (2.0, 0.05), (2.0, 1.5)]:
        r = gca_solve(vg, vd, tab)
        rel, mean_id, _ = pp.continuity_check(r)
        conts.append((vg, vd, rel))
    if verbose:
        print("\n[电流连续性 I_D(y) 沿沟道波动]")
        for vg, vd, rel in conts:
            print(f"  (V_G={vg:.1f}, V_D={vd:.2f}): 相对波动 = {rel:.2e}")

    # ---- 7. 网格收敛 ----
    conv = grid_convergence(vg_max=vg_max, vd_max=vd_max, verbose=verbose)

    # ---- 8. 表格（插值）分辨率收敛 ----
    tconv = table_convergence(x=x, vg_max=vg_max, verbose=verbose)

    result = dict(
        x=x, table=tab, tr=tr, vg=vg_list, id_lin=id_lin, id_sat=id_sat,
        vt_cc=vt_cc, i_th=i_th, ss_lin=ss_lin, ss_sat=ss_sat,
        ss_loc=ss_loc, ss_min=ss_min, ss_th_min=ss_th_min,
        gm=gm, gm_max=gm_max, out=out, vd=vd_list,
        dev_lin_analytic=dev_lin_analytic, dev_lin_fit=dev_lin_fit,
        vg_dev_lin=vg_dev_lin, dev_sat_fit=dev_sat_fit,
        vg_dev_sat=vg_dev_sat,
        conts=conts, conv=conv, tconv=tconv,
        t_table=t_table, t_total=time.time() - t_start,
    )

    # ---- 验证清单（docs/spec/validation_spec.md 四分类）----
    cl = Checklist("stage3")
    # V_T：独立解析参照（长沟道阈值公式）
    d_vt = abs(vt_cc - C.VT_LONG) / C.VT_LONG * 100
    cl.add(metric="阈值电压 V_T（恒定电流判据）", kind=VALIDATION,
           reference="V_T = V_FB + 2psi_F + gamma*sqrt(2psi_F)（体电荷模型）",
           criterion="< 6%",
           measured=f"{vt_cc:.4f} V vs 解析 {C.VT_LONG:.4f} V（{d_vt:.2f}%）",
           passed=d_vt < 6.0,
           note="恒定电流判据（0.1 μA, W/L=1 μm）系统性高于体电荷模型"
                "解析阈值，属判据定义差异而非求解误差")
    # SS 局部最小值 vs 衬偏效应理论下限
    ss_gap = (ss_min - ss_th_min) / ss_th_min * 100
    cl.add(metric="近阈值局部 SS 最小值", kind=VALIDATION,
           reference="SS >= ln10 V_T (1+eps_si/(W_max C_ox))（衬偏效应下限）",
           criterion="不低于理论下限（容差 8%）",
           measured=f"{ss_min:.1f} vs 理论 {ss_th_min:.1f} mV/dec"
                    f"（高 {ss_gap:.1f}%）",
           passed=ss_min >= ss_th_min * 0.92,
           note="残差来自表面网格与表格插值，随加密收敛")
    # 线性区 Square-law 对照（强反型段；V_G=2.0 端点判据，近阈值段记录）
    dev_end = (id_lin[-1] - sq_lin_fit[-1]) / sq_lin_fit[-1] * 100
    cl.add(metric="线性区 I_D vs Square-law（强反型段）", kind=VALIDATION,
           reference="I_D = mu C_ox (W/L)[(V_G-V_T)V_D - V_D^2/2]（提取 V_T）",
           criterion="V_G=2.0 处偏差 < 15%",
           measured=f"V_G=2.0 处 {dev_end:.1f}%；强反型段最大 "
                    f"{dev_lin_fit:.1f}% @ V_G={vg_dev_lin:.2f} V",
           passed=abs(dev_end) < 15.0,
           note="方形律假设 N_s 随 phi_n 严格线性；近阈值段"
                "（V_G≈1.25 V）电荷片指数拖尾使其最快失效，"
                "最大偏差已如实记录")
    # 电流连续性（自洽）
    lin_rel = [r for vg_, vd_, r in conts if vd_ == 0.05]
    sat_rel = [r for vg_, vd_, r in conts if vd_ == 1.5]
    cl.add(metric="沟道电流连续性 I_D(y)（线性区）", kind=SELF_CHECK,
           reference="I_D(y) = q W mu N_s dphi_n/dy 沿沟道应为常数",
           criterion="相对波动 < 1e-3",
           measured="；".join(f"V_G={vg_}: {r:.1e}"
                             for vg_, vd_, r in conts if vd_ == 0.05),
           passed=bool(np.all(np.isfinite(lin_rel)) and
                       max(lin_rel) < 1e-3))
    cl.add(metric="沟道电流连续性 I_D(y)（饱和区）", kind=SELF_CHECK,
           reference="同上",
           criterion="已知模型边界（夹断区漂移近似失效），记录不包装",
           measured="；".join(f"V_G={vg_}: {r:.1e}"
                             for vg_, vd_, r in conts if vd_ == 1.5),
           passed=None,
           note="GCA 漂移近似在夹断区（N_s->0）失效，属已知模型边界")
    # 网格收敛（自洽）：与 grid_convergence() 打印口径一致（强反型段）
    conv_ref = conv[-1]
    vg_conv = np.linspace(0.0, vg_max, 61)
    mask_conv = vg_conv > conv_ref["vt"] + 0.3
    d_vt_conv = max(abs(r["vt"] - conv_ref["vt"]) * 1000 for r in conv[:-1])
    d_id_conv = max(np.max(np.abs(r["id_sat"][mask_conv] -
                                  conv_ref["id_sat"][mask_conv]) /
                           np.maximum(conv_ref["id_sat"][mask_conv], 1e-30))
                    * 100 for r in conv[:-1])
    cl.add(metric="纵向网格收敛（V_T 与 I_D）", kind=SELF_CHECK,
           reference="三级网格 0.5/0.125/0.0625 nm，最细为参考",
           criterion="ΔV_T < 5 mV 且 ΔI_D < 3%",
           measured=f"最大 ΔV_T = {d_vt_conv:.2f} mV；"
                    f"最大 ΔI_D = {d_id_conv:.2f} %",
           passed=bool(d_vt_conv < 5.0 and d_id_conv < 3.0),
           note="粗网格 h0=0.5 nm 的二阶截断；基准/细网格已收敛")
    # 表格分辨率收敛（自洽）：与 table_convergence() 打印口径一致（V_G>1.3）
    tref = tconv[-1]
    vg_tab = np.linspace(0.0, vg_max, 61)
    mask_tab = vg_tab > 1.3
    d_tab_lin = max(np.max(np.abs(r["id_lin"][mask_tab] -
                                  tref["id_lin"][mask_tab]) /
                           tref["id_lin"][mask_tab]) * 100
                    for r in tconv[:-1])
    d_tab_sat = max(np.max(np.abs(r["id_sat"][mask_tab] -
                                  tref["id_sat"][mask_tab]) /
                           tref["id_sat"][mask_tab]) * 100
                    for r in tconv[:-1])
    cl.add(metric="表格（phi_s, phi_n）插值分辨率收敛", kind=SELF_CHECK,
           reference="四档采样，双加密 (400x110) 为参考",
           criterion="线性/饱和区最大偏差 < 2%",
           measured=f"线性 {d_tab_lin:.3f} %，饱和 {d_tab_sat:.3f} %",
           passed=bool(d_tab_lin < 2.0 and d_tab_sat < 2.0))
    # artifact 记录
    cl.add(metric="r_o 伪峰（CLM 开关）", kind=ARTIFACT,
           reference="一阶 CLM 开关处导数不连续",
           criterion="无（artifact 不设判据）",
           measured="见 fig5 标注", artifact="ART-S3-01",
           note="非 Early 效应，已标注（DEF-S3-01）")

    # ---- 系列统一返回结构（docs/spec/code_spec.md：四标准键）----
    result["params"] = dict(NA_CM3=C.NA_CM3, TOX_NM=C.TOX_NM,
                            L_UM=C.L_CH * 1e6, W_UM=C.W_CH * 1e6,
                            VFB=C.VFB, vg_max=vg_max, vd_max=vd_max,
                            table_phi_s=240, table_phi_n=110,
                            grid=dict(d0=0.125e-9, h_max=4.0e-9,
                                      x_max=1.2e-6),
                            i_th_uA=i_th * 1e6, tol=1e-9)
    result["validation"] = cl
    result["defects"] = list(STAGE3_DEFECTS)
    if verbose:
        print(f"\n总耗时 {result['t_total']:.1f} s")
    return result


def square_law_id_vt(vg, vd, vt):
    """用指定阈值 V_T 的 Square-law 电流（与 constants.square_law_id 同一
    公式，但阈值可指定——用于"用提取 V_T 对照"，故公开）。"""
    vg = np.asarray(vg, dtype=float)
    ov = vg - vt
    vdsat = np.maximum(ov, 0.0)
    id_lin = C.MU_N * C.COX * (C.W_CH / C.L_CH) * (ov * vd - 0.5 * vd ** 2)
    id_sat = 0.5 * C.MU_N * C.COX * (C.W_CH / C.L_CH) * vdsat ** 2
    return np.where(ov <= 0.0, 0.0, np.where(vd < vdsat, id_lin, id_sat))


# ================================================================================
# 网格收敛研究
# ================================================================================

def grid_convergence(vg_max=2.0, vd_max=2.0, verbose=True):
    """
    三级纵向网格（粗/基准/细）收敛研究：I_D、V_T、SS 的偏差。

    三个 x 网格配同一套表格配置（phi_s=240, phi_n=55），使对比
    只反映空间离散误差（表格插值误差为共模，在差值中抵消）。
    表面步长序列 0.5/0.125/0.0625 nm，收敛阶 ~2（误差 ~ h^2）。
    """
    grids = [
        ("粗", make_surface_grid(1.2e-6, d0=0.5e-9, h_max=4.0e-9)),
        ("基准", default_x_grid()),
        ("细", make_surface_grid(1.2e-6, d0=0.0625e-9, h_max=4.0e-9)),
    ]
    vg_list = np.linspace(0.0, vg_max, 61)
    records = []
    for name, x in grids:
        # 收敛研究固定表格配置，隔离 x 网格离散误差
        phi_s_grid = np.linspace(-0.3, 1.6, 240)
        phi_n_grid = np.linspace(0.0, 2.0, 55)
        tab = SliceTable(phi_s_grid, phi_n_grid, x)
        tab.build()
        tr = transfer_characteristics(tab, vg_list, vd_lin=0.05, vd_sat=1.5)
        vt_cc, _ = pp.extract_vt(vg_list, tr["id_lin"])
        ss = pp.extract_ss(vg_list, tr["id_lin"])
        records.append(dict(name=name, N=len(x), x=x, id_lin=tr["id_lin"],
                            id_sat=tr["id_sat"], vt=vt_cc, ss=ss, table=tab))
        if verbose:
            print(f"  [{name}] N={len(x):4d}: V_T={vt_cc:.4f} V, "
                  f"SS={ss:.1f} mV/dec")

    ref = records[-1]  # 细网格为参考
    if verbose:
        print("  相对最细网格的偏差（I_D 取强反型段 V_G > V_T + 0.3）：")
    for r in records[:-1]:
        # 强反型段相对偏差
        mask = vg_list > ref["vt"] + 0.3
        d_id = np.max(np.abs(r["id_sat"][mask] - ref["id_sat"][mask]) /
                      np.maximum(ref["id_sat"][mask], 1e-30)) * 100
        d_vt = abs(r["vt"] - ref["vt"]) * 1000   # mV
        d_ss = abs(r["ss"] - ref["ss"])
        if verbose:
            print(f"    {r['name']}: ΔI_D={d_id:.2f} %, ΔV_T={d_vt:.2f} mV, "
                  f"ΔSS={d_ss:.2f} mV/dec")
    return records


def table_convergence(x=None, vg_max=2.0, verbose=True):
    """
    表格（phi_s, phi_n）插值分辨率收敛：固定基准 x 网格，逐步加密
    phi_s / phi_n 采样，记录线性区与饱和区 I_D 的变化。

    物理背景：强反型区 N_s 对 phi_s 极敏感（近似指数），phi_n 在
    夹断附近陡降，故两个方向都需要足够采样；本项给出各自残差。
    """
    if x is None:
        x = default_x_grid()
    cases = [
        ("基准 (240x55)", 240, 55),
        ("phi_s 加密 (400x55)", 400, 55),
        ("phi_n 加密 (240x110)", 240, 110),
        ("双加密 (400x110)", 400, 110),
    ]
    vg_list = np.linspace(0.0, vg_max, 61)
    records = []
    for name, nps, npn in cases:
        tab = SliceTable(np.linspace(-0.3, 1.6, nps),
                         np.linspace(0.0, 2.0, npn), x)
        tab.build()
        id_lin = id_vg(tab, vg_list, 0.05)
        id_sat = id_vg(tab, vg_list, 1.5)
        records.append(dict(name=name, nps=nps, npn=npn, id_lin=id_lin,
                            id_sat=id_sat))
        if verbose:
            print(f"  [{name}] I_D(V_G=2, 线性)={id_lin[-1]:.6e} A, "
                  f"I_D(V_G=2, 饱和)={id_sat[-1]:.6e} A")
    ref = records[-1]
    if verbose:
        print("  相对双加密参考的偏差（强反型段最大相对偏差）：")
    for r in records[:-1]:
        mask = vg_list > 1.3
        d_lin = np.max(np.abs(r["id_lin"][mask] - ref["id_lin"][mask]) /
                       ref["id_lin"][mask]) * 100
        d_sat = np.max(np.abs(r["id_sat"][mask] - ref["id_sat"][mask]) /
                       ref["id_sat"][mask]) * 100
        if verbose:
            print(f"    {r['name']}: ΔI_D(线性)={d_lin:.3f} %, "
                  f"ΔI_D(饱和)={d_sat:.3f} %")
    return records


def main():
    """CLI 入口：完整流程（终端输出双写留存 results/stage3/terminal.txt）。"""
    from common.io import TerminalLog
    with TerminalLog("stage3"):
        run(verbose=True)


if __name__ == "__main__":
    main()
