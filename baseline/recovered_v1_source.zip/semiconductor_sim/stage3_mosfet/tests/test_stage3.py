# -*- coding: utf-8 -*-
"""
stage3_mosfet/tests/test_stage3.py —— MOSFET GCA 单元测试。

由原件 mosfet/tests/test_mosfet.py 迁移（导入改为系列包路径，
_square_law_vt 已公开为 square_law_id_vt）。

覆盖：
    1. 切片平带态 np = n_i²、V_G=0；
    2. 表面电荷三点差分与电荷积分一致；
    3. 栅极 phi_s(V_G) 单调递增；
    4. GCA 线性区还原 Square-law（分区间严格判据 + 符号判据）；
    5. 亚阈值摆幅 SS（固定窗口法）+ 局部 SS 物理下限 + 衬偏效应理论对照；
    6. 弱反型不施加 CLM（亚阈饱和由指数拖尾自然给出）；
    7. 电流连续性：线性区 < 1e-3（验收），饱和区为已知模型边界；
    8. 深反型角点跳过不污染工作区（V_G<=2 全内插、无钳位）。
"""

import warnings

import numpy as np
import pytest

from semiconductor_sim.common import constants as C
from semiconductor_sim.common.grid import make_surface_grid
from semiconductor_sim.stage3_mosfet.solver import (
    solve_slice, surface_charge, electron_sheet_density, total_charge_density)
from semiconductor_sim.stage3_mosfet.table import gate_voltage, SliceTable
from semiconductor_sim.stage3_mosfet.gca import gca_solve, id_vg, id_vd
from semiconductor_sim.stage3_mosfet import postprocess as pp
from semiconductor_sim.stage3_mosfet.run import square_law_id_vt

warnings.filterwarnings("ignore")

X = make_surface_grid(1.2e-6, d0=0.125e-9, h_max=4.0e-9)


@pytest.fixture(scope="module")
def table():
    # 与生产配置一致（240x110），使测试判据与论文发表数字对应
    tab = SliceTable(np.linspace(-0.3, 1.6, 240), np.linspace(0.0, 2.0, 110), X)
    tab.build()
    return tab


@pytest.fixture(scope="module")
def x():
    return X


def test_flatband_equilibrium():
    """平带态：np = n_i²，V_G = 0，Q_s = 0。"""
    res = solve_slice(0.0, 0.0, X)
    npe = np.max(np.abs(res["n"] * res["p"] - C.NI ** 2)) / C.NI ** 2
    assert npe < 1e-10
    qs, _ = surface_charge(res, X)
    assert abs(qs) < 1e-10
    assert abs(gate_voltage(0.0, qs)) < 1e-10


def test_surface_charge_consistency():
    """表面电荷：三点差分与电荷积分一致（弱反型/耗尽区）。"""
    for ps in [0.3, 0.6, 0.85]:
        res = solve_slice(ps, 0.0, X)
        qs3, _ = surface_charge(res, X)
        qs_int = total_charge_density(res, X)
        assert abs(qs3 - qs_int) / abs(qs_int) < 0.02


def test_phi_s_monotonic(table):
    """phi_s(V_G) 单调递增（V_D=0 退化 MOS 电容）。"""
    vg = np.linspace(0.0, 2.0, 41)
    ps = np.array([table.solve_vg(v, 0.0)[0] for v in vg])
    assert np.all(np.diff(ps) >= 0)


def test_gca_linear_square_law(table):
    """
    GCA 线性区与 Square-law（提取 V_T）偏差：分区间严格判据。

    深强反型（V_G >= 1.75）：|偏差| <= 18%（V_G=2 处实测 13.6%）；
    近阈强反型（1.3 <= V_G < 1.75）：|偏差| <= 30%（软开启拖尾，
    V_G≈1.25 处最大 31.4% 出自该区间下沿，不在本判据内）。
    符号判据：GCA 系统性地低于方定律（电荷片物理，见论文 8.6 节）。
    """
    vg_all = np.linspace(0, 2.0, 81)
    id_tmp = id_vg(table, vg_all, 0.05)
    vt, _ = pp.extract_vt(vg_all, id_tmp)
    for lo, hi, bound in [(1.75, 2.0, 18.0), (1.3, 1.75, 30.0)]:
        vg = np.linspace(lo, hi, 11)
        id_gca = id_vg(table, vg, 0.05)
        sq_fit = square_law_id_vt(vg, 0.05, vt)
        dev = (id_gca - sq_fit) / sq_fit * 100
        assert np.all(dev < 0), "GCA 应系统性低于方定律"
        assert np.max(np.abs(dev)) < bound


def test_subthreshold_slope(table):
    """亚阈值摆幅：固定窗口法 65~90 mV/dec；局部最小值与衬偏效应理论一致。"""
    vg = np.linspace(0.0, 2.0, 121)
    id_ = id_vg(table, vg, 0.05)
    ss = pp.extract_ss(vg, id_)
    assert 65.0 < ss < 90.0
    # 局部 SS 曲线：物理下限 ln10*V_T = 59.6 mV/dec 不得被突破
    #（CLM 虚假施加曾导致 V_G≈0.9 处伪 50 mV/dec，回归防护）
    ss_loc = pp.local_ss(vg, id_)
    sub = (vg > 0.5) & (vg < 1.3)
    assert np.nanmin(ss_loc[sub]) > 60.0
    # 近阈值局部最小 SS 与理论 ln10*VT*(1+Cdep(W_max)/Cox) 相差 < 6 mV/dec
    ss_min = np.nanmin(ss_loc[sub])
    ss_th_min = np.log(10) * C.VT * (
        1 + C.EPS_SI / (np.sqrt(2 * C.EPS_SI * C.TWICE_PSI_F /
                               (C.Q_E * C.NA)) * C.COX)) * 1000
    assert abs(ss_min - ss_th_min) < 6.0


def test_clm_not_in_weak_inversion(table):
    """弱反型（V_G=0.9, V_D=0.05）不得被判饱和、不得施加 CLM。"""
    r = gca_solve(0.9, 0.05, table)
    assert not r["saturated"]
    assert r["y_p"] == C.L_CH


def test_continuity_linear(table):
    """电流连续性：线性区 I_D(y) 波动 < 1e-3（验收指标）。"""
    for vg in [1.5, 2.0]:
        r = gca_solve(vg, 0.05, table)
        rel, _, _ = pp.continuity_check(r)
        assert rel < 1e-3


def test_continuity_saturation_known_boundary(table):
    """
    饱和区电流连续性：已知模型边界，不作为验收项。

    夹断截断段由 GCA 构造性给出（phi_n 线性斜坡 + N_s=nmin 平台），
    局部 I_D(y) 在该人工剖面颈部存在固有波动，实测 8.9e-3 > 1e-3
    验收指标。本测试仅防止其进一步劣化（< 3e-2），论文表 5 中
    如实标注为"未达标（模型边界）"。
    """
    r = gca_solve(2.0, 1.5, table)
    rel, _, _ = pp.continuity_check(r)
    assert rel < 3e-2


def test_saturation_plateau(table):
    """饱和区：V_D 增大时 I_D 变化缓慢（平台，含一阶 CLM）。"""
    ids, vdsats, _ = id_vd(table, 2.0, np.linspace(1.5, 2.0, 11))
    # 深饱和段（V_D > V_Dsat）内 I_D 相对变化 < 20%（一阶 CLM）
    rel = (ids[-1] - ids[0]) / ids[0]
    assert 0.0 < rel < 0.20


def test_pinch_off_moves_to_source(table):
    """夹断点随 V_D 增大向源端移动。"""
    _, _, yps = id_vd(table, 2.0, np.array([1.0, 1.5, 2.0]))
    assert yps[-1] < yps[0]     # 向源端（y 减小）


def test_table_column_vs_direct_solve(table, x):
    """表格 phi_n=0 列与同网格直接求解一致（建表自洽性）。"""
    ipn0 = int(np.argmin(np.abs(table.phi_n_grid - 0.0)))
    for ips in [40, 80, 120, 150]:
        ps = table.phi_s_grid[ips]
        if not np.isfinite(table.vg[ips, ipn0]):
            continue
        res = solve_slice(ps, 0.0, x)
        qs, _ = surface_charge(res, x)
        vg = C.VFB + ps - qs / C.COX
        ns = electron_sheet_density(res, x)
        assert abs(vg - table.vg[ips, ipn0]) < 1e-6 * max(1.0, abs(vg))
        assert abs(qs - table.qs[ips, ipn0]) < 1e-6 * max(1e-4, abs(qs))
        assert abs(ns - table.ns[ips, ipn0]) < 1e-4 * max(1e10, ns)


def test_skip_corner_does_not_clamp_workspace(table):
    """
    深反型角点（phi_s-phi_n>0.9）跳过后，V_G<=2 V 工作区内所有
    phi_n 列必须为内插（有效 V_G 上限 > 2 V），不得发生钳位外推。
    """
    for ipn in range(table.npn):
        colv = np.isfinite(table.vg[:, ipn])
        assert table.vg[colv, ipn].max() > 2.0
