# -*- coding: utf-8 -*-
"""
第三阶段 MOSFET 论文插图生成（输出到 results_mosfet/）。

图清单（按论文出现顺序编号）：
    fig1_slice_profiles   单截面电势/载流子/电场（线性区与饱和区）
    fig2_channel_profile  沟道 phi_n(y) 与 N_s(y)（含夹断）
    fig3_id_vg            I_D-V_G（线性 + 对数亚阈值 + 局部 SS 理论对照）
    fig4_id_vd            I_D-V_D 曲线族
    fig5_gm_ro            g_m-V_G 与 r_o-V_D（伪峰标注）
    fig6_square_law       与 Square-law 对照（最大偏差标注）
    fig7_grid_conv        纵向网格收敛
    fig8_table_conv       表格（phi_s, phi_n）插值分辨率收敛
    fig9_continuity       电流连续性校验（线性区达标/饱和区已知边界）
    fig10_cv_loop         与第一阶段 MOS C-V 闭环对照
"""

import os
import warnings

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from common import constants as C
from common.io import ensure_results_dir
from .table import SliceTable
from .solver import solve_slice, surface_charge, electron_sheet_density
from .gca import (gca_solve, id_vg, transfer_characteristics,
                  output_characteristics)
from . import postprocess as pp
from .run import default_table, default_x_grid, square_law_id_vt

plt.rcParams.update({
    "font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9,
    "figure.dpi": 110, "savefig.dpi": 130,
})


def _register_cjk_font():
    """注册 Noto Sans CJK SC 供图内中文使用（fig7/fig8 的 legend 含
    "粗/基准/细"、"加密"等中文；matplotlib 默认 DejaVu Sans 不含 CJK
    字形，会渲染成方框）。

    系统 ttc（NotoSansCJK-Regular.ttc）是多 face 集合，addfont 只注册
    首个 face（JP），故用 fontTools 抽取 SC face 到缓存目录再注册；
    fontTools 为 weasyprint 的既有依赖。找不到字体时静默跳过（图仍可
    生成，仅中文退化为方框），不影响任何数值。
    """
    have = {f.name for f in matplotlib.font_manager.fontManager.ttflist}
    if "Noto Sans CJK SC" in have:
        return True
    import glob
    import tempfile
    for path in sorted(glob.glob(
            "/usr/share/fonts/**/NotoSansCJK-Regular.ttc", recursive=True)
            + glob.glob("/usr/share/fonts/**/NotoSansCJK*.ttc",
                        recursive=True)):
        try:
            from fontTools.ttLib import TTCollection
            coll = TTCollection(path, lazy=False)
            for face in coll.fonts:
                if face["name"].getDebugName(4) != "Noto Sans CJK SC":
                    continue
                cache = os.path.join(tempfile.gettempdir(),
                                     "NotoSansCJKsc-Regular.otf")
                face.save(cache)
                matplotlib.font_manager.fontManager.addfont(cache)
                plt.rcParams["font.sans-serif"] = [
                    "Noto Sans CJK SC", "DejaVu Sans"]
                plt.rcParams["axes.unicode_minus"] = False
                return True
        except Exception:
            continue
    return False


_CJK_OK = _register_cjk_font()


def _outdir(outdir):
    """outdir 缺省解析为 results/stage3/（系列统一结果目录）；显式传入时
    确保目录存在。"""
    if outdir is None:
        return ensure_results_dir("stage3")
    os.makedirs(outdir, exist_ok=True)
    return outdir


def fig_slice_profiles(table, x, outdir=None):
    """图 1：单截面纵向剖面（线性区 V_G=2.0, phi_n=0 与饱和区 phi_n=1.0）。

    电场峰值在正文中引用：线性区源端 ~1.8e5 V/cm，饱和区 ~6.9e4 V/cm
    （深反型角点 phi_s=1.45 的直接解 E 达 3e7 V/cm，无物理意义，这正是
    建表跳过该角点的原因）。
    """
    outdir = _outdir(outdir)
    fig, axes = plt.subplots(1, 3, figsize=(9.5, 2.9))
    for phi_n, lab, c in [(0.0, "linear ($\\phi_n$=0)", "tab:blue"),
                          (1.0, "saturation ($\\phi_n$=1)", "tab:red")]:
        ps, _, _ = table.solve_vg(2.0, phi_n)
        res = solve_slice(ps, phi_n, x)
        xnm = x * 1e9
        e = -np.gradient(res["phi"], x) * 1e-2   # V/cm
        axes[0].plot(xnm, res["phi"], color=c, label=lab)
        axes[1].plot(xnm, res["n"] * 1e-6, color=c, label=lab)   # cm^-3
        axes[2].plot(xnm, e, color=c, label=f"{lab}, E$_{{max}}$={e.max():.1e}")
    axes[0].set_xlabel("x (nm)"); axes[0].set_ylabel("$\\phi$ (V)"); axes[0].set_title("potential")
    axes[1].set_xlabel("x (nm)"); axes[1].set_ylabel("n (cm$^{-3}$)"); axes[1].set_title("electron density")
    axes[2].set_xlabel("x (nm)"); axes[2].set_ylabel("E (V/cm)"); axes[2].set_title("electric field")
    axes[1].set_yscale("log")
    for a in axes:
        a.set_xlim(0, 400); a.legend(fontsize=6.5); a.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig1_slice_profiles.png"), bbox_inches="tight")
    plt.close(fig)


def fig_channel_profile(table, outdir=None):
    """图 2：沟道 phi_n(y) 与 N_s(y)（线性区 + 饱和区含夹断）。"""
    outdir = _outdir(outdir)
    y = np.linspace(0, C.L_CH, 161)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for vg, vd, lab in [(2.0, 0.05, "linear"), (2.0, 1.5, "saturation")]:
        r = gca_solve(vg, vd, table, y=y)
        ynm = r["y"] * 1e9
        axes[0].plot(ynm, r["phi_n"], label=f"{lab} (V_D={vd})")
        axes[1].plot(ynm, r["ns"] * 1e-4, label=f"{lab} (V_D={vd})")  # cm^-2
        if r["saturated"]:
            axes[0].axvline(r["y_p"] * 1e9, color="gray", ls="--", lw=1)
            axes[1].axvline(r["y_p"] * 1e9, color="gray", ls="--", lw=1,
                            label=f"pinch-off y_p={r['y_p']*1e9:.0f} nm")
    axes[0].set_xlabel("y (nm)"); axes[0].set_ylabel("phi_n (V)")
    axes[1].set_xlabel("y (nm)"); axes[1].set_ylabel("N_s (cm$^{-2}$)")
    for a in axes:
        a.legend(fontsize=7); a.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig2_channel_profile.png"), bbox_inches="tight")
    plt.close(fig)


def fig_id_vg(tr, vt_cc, table=None, outdir=None):
    """图 3：I_D-V_G 线性/对数坐标 + 局部 SS 与衬偏效应理论对照。"""
    outdir = _outdir(outdir)
    vg = tr["vg"]
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 2.8))
    axes[0].plot(vg, tr["id_lin"] * 1e6, label="V_D=0.05 V")
    axes[0].plot(vg, tr["id_sat"] * 1e6, label="V_D=1.5 V")
    axes[0].axvline(vt_cc, color="gray", ls="--", lw=1, label=f"V_T={vt_cc:.3f} V")
    axes[0].set_xlabel("V_G (V)"); axes[0].set_ylabel("I_D (μA)")
    axes[0].legend(fontsize=7); axes[0].grid(alpha=0.3)
    axes[1].semilogy(vg, tr["id_lin"], label="V_D=0.05 V")
    axes[1].semilogy(vg, tr["id_sat"], label="V_D=1.5 V")
    axes[1].axvline(vt_cc, color="gray", ls="--", lw=1)
    axes[1].set_xlabel("V_G (V)"); axes[1].set_ylabel("I_D (A)")
    axes[1].legend(fontsize=7); axes[1].grid(alpha=0.3)
    # 局部 SS vs 衬偏效应理论
    if table is not None:
        ss_loc = pp.local_ss(vg, tr["id_lin"])
        ps_arr = np.array([table.solve_vg(v, 0.0)[0] for v in vg])
        ss_th = pp.ss_theory(ps_arr)
        m = (vg > 0.4) & (vg < 1.25)
        axes[2].plot(vg[m], ss_loc[m], ".", ms=4, label="local SS (model)")
        axes[2].plot(vg[m], ss_th[m], "-", lw=1.2,
                     label="$\\ln10\\,V_T(1+C_{dep}/C_{ox})$")
        axes[2].set_xlabel("V_G (V)")
        axes[2].set_ylabel("SS (mV/dec)")
        axes[2].set_ylim(55, 130)
        axes[2].legend(fontsize=7); axes[2].grid(alpha=0.3)
        axes[2].set_title("subthreshold swing", fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig3_id_vg.png"), bbox_inches="tight")
    plt.close(fig)


def fig_id_vd(out, vt_cc, outdir=None):
    """图 4：I_D-V_D 曲线族。"""
    outdir = _outdir(outdir)
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    for i, vg in enumerate(out["vg"]):
        ax.plot(out["vd"], out["ids"][i] * 1e6, label=f"V_G={vg:.1f} V")
        # 夹断电压（V_Dsat = vdsat）
        vdsat = out["vdsats"][i][-1]
        ax.axvline(vdsat, color=f"C{i}", ls=":", lw=0.8, alpha=0.6)
    ax.set_xlabel("V_D (V)"); ax.set_ylabel("I_D (μA)")
    ax.legend(fontsize=7); ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig4_id_vd.png"), bbox_inches="tight")
    plt.close(fig)


def fig_gm_ro(vg, id_sat, vd, ids, outdir=None):
    """图 5：g_m-V_G 与 r_o-V_D。r_o 伪峰为一阶 CLM 开关 artifact，标注。"""
    outdir = _outdir(outdir)
    gm, _ = pp.extract_gm(vg, id_sat)
    ro = pp.extract_ro(vd, ids[-1])   # 最高 V_G 的输出电阻
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    axes[0].plot(vg, gm * 1e6)
    axes[0].set_xlabel("V_G (V)"); axes[0].set_ylabel("g_m (μS)")
    axes[0].grid(alpha=0.3)
    axes[1].plot(vd, ro * 1e-6)
    axes[1].set_xlabel("V_D (V)"); axes[1].set_ylabel("r_o (MΩ)")
    axes[1].grid(alpha=0.3)
    # 伪峰标注：指数拖尾收敛 -> CLM 开关处的导数不连续
    i_pk = int(np.nanargmax(np.where(np.isfinite(ro), ro, -np.inf)))
    if np.isfinite(ro[i_pk]) and ro[i_pk] > 1e5:
        axes[1].annotate("artifact: CLM switch\n(not Early effect)",
                         xy=(vd[i_pk], ro[i_pk] * 1e-6),
                         xytext=(vd[i_pk] + 0.35, ro[i_pk] * 0.45 * 1e-6),
                         fontsize=7, color="tab:red",
                         arrowprops=dict(arrowstyle="->", color="tab:red",
                                         lw=0.8))
        axes[1].set_yscale("log")
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig5_gm_ro.png"), bbox_inches="tight")
    plt.close(fig)


def fig_square_law(vg, id_lin, id_sat, vt_cc, outdir=None):
    """图 6：与 Square-law 对照（用提取 V_T），标注最大偏差点与数值。"""
    outdir = _outdir(outdir)
    sq_lin = square_law_id_vt(vg, 0.05, vt_cc)
    sq_sat = square_law_id_vt(vg, 1.5, vt_cc)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for ax, idd, sq, ttl in [
            (axes[0], id_lin, sq_lin, "linear (V_D=0.05 V)"),
            (axes[1], id_sat, sq_sat, "saturation (V_D=1.5 V)")]:
        ax.plot(vg, idd * 1e6, label="GCA")
        ax.plot(vg, sq * 1e6, "--", label="Square-law")
        m = vg > vt_cc + 0.2
        dev = (idd[m] - sq[m]) / sq[m] * 100
        i = int(np.argmax(np.abs(dev)))
        vg_m = vg[m][i]
        ax.plot(vg_m, idd[m][i] * 1e6, "o", ms=5, color="tab:red", zorder=5)
        ax.annotate(f"max |dev| = {abs(dev[i]):.1f}%\n@ V_G={vg_m:.2f} V",
                    xy=(vg_m, idd[m][i] * 1e6),
                    xytext=(vg_m - 0.62, idd[m][i] * 1e6 * 0.45),
                    fontsize=7, color="tab:red",
                    arrowprops=dict(arrowstyle="->", color="tab:red", lw=0.8))
        ax.set_xlabel("V_G (V)"); ax.set_ylabel("I_D (μA)")
        ax.set_title(ttl, fontsize=9)
        ax.legend(fontsize=7); ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig6_square_law.png"), bbox_inches="tight")
    plt.close(fig)


def fig_grid_conv(records, outdir=None):
    """图 7：网格收敛（I_D-V_G 三级网格）。"""
    outdir = _outdir(outdir)
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    for r in records:
        ax.plot(np.linspace(0, 2.0, 61), r["id_sat"] * 1e6,
                label=f"{r['name']} (N={r['N']})")
    ax.set_xlabel("V_G (V)"); ax.set_ylabel("I_D (μA)")
    ax.legend(fontsize=7); ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig7_grid_conv.png"), bbox_inches="tight")
    plt.close(fig)


def fig_continuity(table, outdir=None):
    """图 9：电流连续性 I_D(y) 沿沟道（线性区达标；饱和区为已知模型边界）。"""
    outdir = _outdir(outdir)
    y = np.linspace(0, C.L_CH, 161)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for vg, vd in [(2.0, 0.05), (1.5, 0.05)]:
        r = gca_solve(vg, vd, table, y=y)
        rel, _, _ = pp.continuity_check(r)
        axes[0].plot(r["y"] * 1e9, r["id_local"] * 1e6,
                     label=f"V_G={vg}, V_D={vd} (fluct. {rel:.1e})")
    axes[0].set_xlabel("y (nm)"); axes[0].set_ylabel("I_D(y) (μA)")
    axes[0].set_title("linear region (pass < 1e-3)", fontsize=9)
    axes[0].legend(fontsize=7); axes[0].grid(alpha=0.3)
    r = gca_solve(2.0, 1.5, table, y=y)
    rel, _, _ = pp.continuity_check(r)
    axes[1].plot(r["y"] * 1e9, r["id_local"] * 1e6)
    axes[1].axvline(r["y_p"] * 1e9, color="gray", ls="--", lw=1)
    axes[1].set_xlabel("y (nm)"); axes[1].set_ylabel("I_D(y) (μA)")
    axes[1].set_title(f"saturation: fluct. {rel:.1e} "
                      "(known boundary, not a pass)", fontsize=9)
    axes[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig9_continuity.png"), bbox_inches="tight")
    plt.close(fig)


def fig_table_conv(trecords, vg_max=2.0, outdir=None):
    """图 8：表格（phi_s, phi_n）插值分辨率收敛。"""
    outdir = _outdir(outdir)
    vg = np.linspace(0.0, vg_max, 61)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for r in trecords:
        axes[0].plot(vg, r["id_sat"] * 1e6, label=r["name"])
        axes[1].plot(vg, r["id_lin"] * 1e6, label=r["name"])
    axes[0].set_title("saturation (V_D=1.5)")
    axes[1].set_title("linear (V_D=0.05)")
    for a in axes:
        a.set_xlabel("V_G (V)"); a.set_ylabel("I_D (μA)")
        a.legend(fontsize=6); a.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig8_table_conv.png"), bbox_inches="tight")
    plt.close(fig)


def fig_cv_loop(table, x, outdir=None):
    """图 10：与第一阶段 MOS C-V 闭环对照（phi_n=0 列 vs 第一阶段求解器）。

    只取物理重叠区 phi_s ∈ [-0.15, 1.6]（V_G ≈ [-1, 2.6] V）：深积累
    角区（phi_s << 0）的积累层厚度低于网格分辨率、Q_s 被 mesh 主导，
    两阶段均不具物理意义，不予比较。右图为等效栅压误差 |ΔQ_s|/C_ox。
    """
    outdir = _outdir(outdir)
    from stage1_mos.solver import solve_poisson
    from stage1_mos.postprocess import postprocess as s1_postprocess
    phi_s_arr = np.linspace(-0.15, 1.6, 120)
    # 第三阶段：表格 phi_n=0 列
    ipn0 = int(np.argmin(np.abs(table.phi_n_grid - 0.0)))
    vg3 = table.vg[:, ipn0]
    qs3 = table.qs[:, ipn0]
    m3 = np.isfinite(vg3) & (vg3 > -1.2) & (vg3 < 2.8)
    # 第一阶段：同一 x 网格上直接解 Poisson，按 phi_s 参数延续（与其
    # run() 的策略一致）。注：细网格上单点冷启动会因 tol=1e-11 过紧
    # 加 Armijo 步长减半而停顿（dmove 卡在 2.4e-10），延续可全范围收敛。
    qs1, vg1 = [], []
    prev = None
    for ps in phi_s_arr:
        phi, _, conv = solve_poisson(ps, x, C.NA, phi_init=prev)
        prev = phi
        qs, _ = s1_postprocess(phi, x)
        qs1.append(qs)
        vg1.append(C.VFB + ps - qs / C.COX)
    qs1 = np.array(qs1); vg1 = np.array(vg1)
    # 对齐到共同 V_G 网格比较（仅重叠区）
    vg_common = np.linspace(-1.0, 2.5, 240)
    qs3_i = np.interp(vg_common, vg3[m3], qs3[m3])
    qs1_i = np.interp(vg_common, vg1, qs1)
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8))
    axes[0].plot(vg3[m3], qs3[m3] * 1e3, ".", ms=3,
                 label="stage-3 table ($\\phi_n$=0)")
    axes[0].plot(vg1, qs1 * 1e3, "-", lw=1, label="stage-1 solver")
    axes[0].set_xlabel("V_G (V)"); axes[0].set_ylabel("Q_s (mC/m$^2$)")
    axes[0].set_xlim(-1.2, 2.8)
    axes[0].legend(fontsize=7); axes[0].grid(alpha=0.3)
    dvg = np.abs(qs3_i - qs1_i) / C.COX * 1e3      # mV
    axes[1].semilogy(vg_common, np.maximum(dvg, 1e-4))
    axes[1].set_xlabel("V_G (V)")
    axes[1].set_ylabel("|ΔQ_s|/C_ox (mV)")
    axes[1].set_ylim(1e-3, 1e2)
    axes[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, "fig10_cv_loop.png"), bbox_inches="tight")
    plt.close(fig)
    # 数值摘要（论文引用）
    i0 = np.argmin(np.abs(vg_common - 0.0))
    i1 = np.argmin(np.abs(vg_common - 1.0))
    i2 = np.argmin(np.abs(vg_common - 2.0))
    for iv, nm in [(i0, "V_G=0"), (i1, "V_G=1"), (i2, "V_G=2")]:
        print(f"  [C-V 闭环] {nm}: 第三阶段 Q_s={qs3_i[iv]*1e3:.4f} mC/m^2, "
              f"第一阶段 Q_s={qs1_i[iv]*1e3:.4f} mC/m^2, "
              f"等效差 {dvg[iv]:.3f} mV")


def make_figures(table=None, x=None, tr=None, out=None, records=None,
                 vt_cc=None, trecords=None, outdir=None):
    """生成全部插图（fig1-fig10）。若未传表格则现场构建。"""
    outdir = _outdir(outdir)
    warnings.filterwarnings("ignore")
    if x is None:
        x = default_x_grid()
    if table is None:
        table = default_table(x)
        table.build()
    if vt_cc is None:
        vg_tmp = np.linspace(0, 2.0, 81)
        id_tmp = id_vg(table, vg_tmp, 0.05)
        vt_cc, _ = pp.extract_vt(vg_tmp, id_tmp)
    if tr is None:
        tr = transfer_characteristics(table, np.linspace(0, 2.0, 81),
                                      vd_lin=0.05, vd_sat=1.5)
    if out is None:
        out = output_characteristics(table, [1.2, 1.5, 2.0],
                                     np.linspace(0, 2.0, 61))
    fig_slice_profiles(table, x, outdir)
    fig_channel_profile(table, outdir)
    fig_id_vg(tr, vt_cc, table, outdir)
    fig_id_vd(out, vt_cc, outdir)
    fig_gm_ro(tr["vg"], tr["id_sat"], out["vd"], out["ids"], outdir)
    fig_square_law(tr["vg"], tr["id_lin"], tr["id_sat"], vt_cc, outdir)
    if records is not None:
        fig_grid_conv(records, outdir)
    if trecords is not None:
        fig_table_conv(trecords, outdir=outdir)
    fig_continuity(table, outdir)
    fig_cv_loop(table, x, outdir)
    print(f"插图已输出到 {outdir}/")
    return outdir


if __name__ == "__main__":
    from .run import grid_convergence, table_convergence
    x = default_x_grid()
    tab = default_table(x)
    tab.build()
    tr = transfer_characteristics(tab, np.linspace(0, 2.0, 81),
                                  vd_lin=0.05, vd_sat=1.5)
    out = output_characteristics(tab, [1.2, 1.5, 2.0], np.linspace(0, 2.0, 61))
    records = grid_convergence(verbose=False)
    trecords = table_convergence(x=x, verbose=False)
    make_figures(tab, x, tr, out, records, trecords=trecords)
