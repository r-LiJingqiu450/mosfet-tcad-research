# -*- coding: utf-8 -*-
"""
单截面纵向 Poisson（准平衡）求解器 —— 第三阶段 MOSFET 的核心引擎。

系列化说明：三对角求解统一走 common.thomas.thomas_solve_banded
（scipy LAPACK 带状优先、纯 Python 回退）；全部物理常数取自
common.constants（全系列唯一参数源）。

物理模型（电荷片 / 渐变沟道近似 GCA 的标准基础）：

    沿沟道 y 分 Ny 个截面；每个截面在"垂直于界面"的 x 方向做准平衡
    （quasi-equilibrium）求解：载流子随纵向能带弯曲按 Boltzmann 分布，
    电子准费米势 phi_n(y) 在该截面内取常数（由源漏/沟道决定），
    空穴与衬底平衡（phi_p = 0）：

        d^2 phi/dx^2 = -(q/eps_si)(p - n - Na)
        p = p0 exp(-phi/V_T)
        n = n0 exp(phi/V_T) exp(-phi_n/V_T)

    边界：phi(0)=phi_s（栅界面），phi(x_max)=0（衬底体内参考）。
    栅压由栅极混合边界反算：V_G = V_FB + phi_s - Q_s/C_ox。

为什么用准平衡 Poisson 而非全 DD：
    均匀 p 衬底 + 反型层边界的"最小结构"没有 n+ 电子源，耗尽区
    n ~ 0 处处，电子连续性方程退化（0=0），全 DD 的 Newton 在该区
    奇异。准平衡 Poisson 在亚阈值→强反型全范围内稳健，且 V_D=0
    时严格退化为第一阶段 MOS 电容求解器（phi_n=0 时 n=n0 exp(phi/V_T)）。
    全 DD（复用第二阶段 SG/QFP/块 Thomas）将在加入 n+ 源漏时启用。

约定（与第一阶段 mos_capacitor.py 一致）：
    phi 相对衬底体内（phi_bulk = 0），x 指向衬底。
"""

import warnings

import numpy as np

from common import constants as C
from common.thomas import thomas_solve_banded


# ================================================================================
# Poisson 残差与 Newton
# ================================================================================

def _residual(phi, phi_n, p0, n0, Na_arr, aa, bb0, cc):
    """
    泊松残差 F_i（内部节点）：
        F = lap - (q/eps)(p - n - Na) * (节点控制体积权重)
    采用第一阶段相同的非均匀二阶中心差分 + 电荷权重。

    p = p0 exp(-phi/V_T),  n = n0 exp(phi/V_T) exp(-phi_n/V_T)。
    """
    phi_c = np.clip(phi, -3.0, 3.0)
    p = p0 * np.exp(-phi_c / C.VT)
    n = n0 * np.exp(phi_c / C.VT) * np.exp(-phi_n / C.VT)
    lap = aa * phi[:-2] + bb0 * phi[1:-1] + cc * phi[2:]
    return lap + (C.Q_E / C.EPS_SI) * (p[1:-1] - n[1:-1] - Na_arr[1:-1])


def solve_poisson_slice(phi_s, phi_n_ch, x, Na=C.NA, phi_init=None,
                        tol=1e-9, max_iter=200, clamp=0.3, warn=True,
                        damped=True, max_backtrack=12):
    """
    解单截面的准平衡 Poisson 方程（推广第一阶段 solve_poisson 至 phi_n≠0）。

    参数
    ----
    phi_s    : 表面势 (V)，相对衬底体内
    phi_n_ch : 沟道电子准费米势 (V)，本截面内取常数
    x        : 纵向网格 (m)，x[0]=栅界面，x[-1]=衬底接触
    phi_init : 初值（None 用耗尽近似抛物线/德拜尾猜测）
    tol      : 收敛判据 max|Delta phi| (V)。默认 1e-9：实测 dmove<1e-11
               的解残差已处双精度底噪（|F| ~ 1e3 V/m^2，相对电荷项
               1e13 为 1e-10），且 N_s 对 phi 的敏感度为 1/V_T，
               phi 误差 1e-9 V 仅引起 N_s 相对误差 4e-8，可忽略；
               1e-11 反而使热启动在真解附近因舍入噪声无法收敛。

    返回 dict：phi, n, p, iters, converged
    """
    N = len(x)
    hs = np.diff(x)
    hL = hs[:-1]
    hR = hs[1:]
    sumLR = hL + hR
    aa = 2.0 / (hL * sumLR)
    bb0 = -2.0 / (hL * hR)
    cc = 2.0 / (hR * sumLR)

    p0 = 0.5 * (Na + np.sqrt(Na ** 2 + 4.0 * C.NI ** 2))
    n0 = C.NI ** 2 / p0
    Na_arr = np.full_like(x, Na, dtype=float)
    phi_n = np.full_like(x, phi_n_ch, dtype=float)   # 截面内常数

    if phi_init is None:
        # 冷启动初值：耗尽近似抛物线 / 积累德拜尾（比线性猜测更接近真解）
        L_D = np.sqrt(C.EPS_SI * C.VT / (C.Q_E * Na))
        if phi_s > 0.0:
            W = min(np.sqrt(2.0 * C.EPS_SI * phi_s / (C.Q_E * Na)), x[-1])
            phi = np.where(x < W, phi_s * (1.0 - x / W) ** 2, 0.0)
        elif phi_s < 0.0:
            phi = phi_s * np.exp(-x / L_D)
        else:
            phi = np.zeros_like(x)
        phi = phi.astype(float)
    elif len(phi_init) == len(x):
        # 同一网格的热启动：直接使用（切勿按均匀辅助网格重采样——
        # x 非均匀时会把表层剖面打乱，导致 Newton 从错误初值缓慢爬行）
        phi = np.asarray(phi_init, dtype=float).copy()
    else:
        # 跨网格延续：按均匀辅助网格插值（仅用于网格不同的场合）
        phi = np.interp(x, np.linspace(0, x[-1], len(phi_init)), phi_init)
        phi = phi.astype(float)
    phi[0] = phi_s
    phi[-1] = 0.0

    converged = False
    niter = max_iter
    F = _residual(phi, phi_n, p0, n0, Na_arr, aa, bb0, cc)
    normF = np.linalg.norm(F)
    # 残差舍入底噪：差分系数 2/h^2 最大 ~1e20（d0=0.125nm 时），phi 的
    # 双精度噪底乘以该系数即 |F| 的不可再降下限。线搜索在该底噪附近做
    # 充分下降检查必然失败（纯舍入抖动），故直接接受全步、由 dmove
    # 判据终止，避免每步 12 次无效回溯。
    src_scale = (C.Q_E / C.EPS_SI) * Na * np.sqrt(max(N - 2, 1))
    noise_floor = 1e-10 * src_scale

    for niter in range(1, max_iter + 1):
        phi_c = np.clip(phi, -3.0, 3.0)
        p = p0 * np.exp(-phi_c / C.VT)
        n = n0 * np.exp(phi_c / C.VT) * np.exp(-phi_n / C.VT)

        b_diag = bb0 - (C.Q_E ** 2 / (C.EPS_SI * C.K_B * C.TEMP)) * \
            (p[1:-1] + n[1:-1])
        a_low = aa.copy()
        a_low[0] = 0.0
        c_up = cc.copy()
        c_up[-1] = 0.0

        delta = thomas_solve_banded(a_low, b_diag, c_up, -F)
        delta = np.clip(delta, -clamp, clamp)

        alpha = 1.0
        if damped and normF > noise_floor:
            for _ in range(max(1, int(max_backtrack))):
                phi_try = phi.copy()
                phi_try[1:-1] += alpha * delta
                F_try = _residual(phi_try, phi_n, p0, n0, Na_arr, aa, bb0, cc)
                normF_try = np.linalg.norm(F_try)
                if normF_try <= (1.0 - 2e-4 * alpha) * normF:
                    break
                alpha *= 0.5
            phi, F, normF = phi_try, F_try, normF_try
            dmove = alpha * np.max(np.abs(delta))
        else:
            phi[1:-1] += delta
            F = _residual(phi, phi_n, p0, n0, Na_arr, aa, bb0, cc)
            normF = np.linalg.norm(F)
            dmove = np.max(np.abs(delta))

        phi[0] = phi_s
        phi[-1] = 0.0

        if dmove < tol:
            converged = True
            break

    if not converged and warn:
        warnings.warn(
            f"solve_poisson_slice: 未在 {max_iter} 步内收敛 "
            f"(phi_s={phi_s:.4f} V, phi_n={phi_n_ch:.4f} V)。",
            RuntimeWarning, stacklevel=2)

    # 还原载流子
    phi_c = np.clip(phi, -3.0, 3.0)
    p = p0 * np.exp(-phi_c / C.VT)
    n = n0 * np.exp(phi_c / C.VT) * np.exp(-phi_n / C.VT)
    return dict(phi=phi, n=n, p=p, iters=niter, converged=converged)


# ================================================================================
# 掺杂剖面（原 doping.py，并入本模块：最小闭环仅一处使用）
# ================================================================================

def doping_profile(x, Na):
    """
    返回 (Na_arr, Nd_arr)（m^-3），长度与 x 一致。

    最小闭环为均匀 p 衬底：Na_arr = Na 常数，Nd_arr = 0。
    """
    Na_arr = np.full_like(x, Na, dtype=float)
    Nd_arr = np.zeros_like(x, dtype=float)
    return Na_arr, Nd_arr


# ================================================================================
# 统一入口（兼容 gate_boundary 调用）与后处理：电荷 / 面密度
# ================================================================================

def solve_slice(phi_s, phi_n_ch, x, Na=C.NA, state=None,
                tol=1e-9, max_iter=200, clamp=0.3, verbose=False,
                warn=True):
    """
    单截面求解统一入口。最小闭环用准平衡 Poisson。

    state 可选：上一个 (phi, n, p) 解，作为初值加速延续收敛。
    """
    phi_init = state[0] if state is not None else None
    res = solve_poisson_slice(phi_s, phi_n_ch, x, Na=Na,
                              phi_init=phi_init, tol=tol,
                              max_iter=max_iter, clamp=clamp,
                              warn=warn)
    return res


# ================================================================================
# 后处理：电荷 / 面密度
# ================================================================================

def surface_charge(res, x):
    """
    半导体总面电荷 Q_s = eps_si dphi/dx|_0（三点一阶前向差分，同第一阶段）。
    返回 (Q_s, E_s)。
    """
    phi = res["phi"]
    h0 = x[1] - x[0]
    dphi_dx0 = (-3.0 * phi[0] + 4.0 * phi[1] - phi[2]) / (2.0 * h0)
    Q_s = C.EPS_SI * dphi_dx0
    E_s = -dphi_dx0
    return Q_s, E_s


def electron_sheet_density(res, x):
    """电子面密度 N_s = ∫ n dx（m^-2），梯形积分。"""
    n = res["n"]
    hw = np.diff(x)
    return float(np.sum(0.5 * (n[:-1] + n[1:]) * hw))


def hole_sheet_density(res, x):
    """空穴面密度 ∫ p dx（m^-2）。"""
    p = res["p"]
    hw = np.diff(x)
    return float(np.sum(0.5 * (p[:-1] + p[1:]) * hw))


def total_charge_density(res, x, Na=C.NA):
    """总空间电荷面密度 Q_s = q ∫ (p - n - Na) dx（C/m^2），供交叉校验。"""
    p = res["p"]
    n = res["n"]
    Na_arr = np.full_like(x, Na, dtype=float)
    rho = C.Q_E * (p - n - Na_arr)
    hw = np.diff(x)
    return float(np.sum(0.5 * (rho[:-1] + rho[1:]) * hw))
