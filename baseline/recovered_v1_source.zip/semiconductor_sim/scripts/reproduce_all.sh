#!/usr/bin/env bash
# reproduce_all.sh —— 一维半导体器件数值仿真系列一键复现（reproduce_spec.md 第 1、2 节）。
#
# 覆盖：三阶段主流程（终端校验行写入 results/stageX/terminal.txt）→ 出图 →
#       golden 基准回归比对 → 全量测试。
#
# 用法：
#   bash semiconductor_sim/scripts/reproduce_all.sh            # 完整复现
#   bash semiconductor_sim/scripts/reproduce_all.sh --no-test  # 只跑流程与出图
#
# 约定（reproduce_spec.md 第 3 节）：
#   - golden 基准文件随源码提交，tests/test_golden.py 以 rtol=1e-6 比对；
#   - 更新基准必须显式执行 scripts/make_golden.py 并在提交信息注明原因，
#     本脚本绝不静默改写基准；
#   - 报告构建（python build_paper.py）不在本脚本内：构建不出新数值，
#     只把已有 terminal.txt / figures/ 排版成 PDF。

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(dirname "$HERE")"                        # scripts -> semiconductor_sim（仓库根）
PARENT="$(dirname "$REPO")"                      # semiconductor_sim -> 工作区根
cd "$PARENT"

echo "== 环境 =="
python -c "import sys, numpy, scipy, matplotlib; print('Python', sys.version.split()[0], '| numpy', numpy.__version__, '| scipy', scipy.__version__, '| matplotlib', matplotlib.__version__)" \
  || python -c "import sys, numpy, matplotlib; print('Python', sys.version.split()[0], '| numpy', numpy.__version__, '| matplotlib', matplotlib.__version__, '（无 scipy，求解器回退纯 Python）')"

echo "== S1 主流程 =="
python -m semiconductor_sim.stage1_mos.run

echo "== S2 主流程 =="
python -m semiconductor_sim.stage2_pn.run

echo "== S3 主流程 =="
python -m semiconductor_sim.stage3_mosfet.run

echo "== 出图 =="
python -m semiconductor_sim.stage1_mos.make_figures
python -m semiconductor_sim.stage2_pn.make_figures
python -m semiconductor_sim.stage3_mosfet.make_figures

if [[ "${1:-}" == "--no-test" ]]; then
  echo "== 跳过测试（--no-test）=="
  exit 0
fi

echo "== golden 基准比对 + 全量测试 =="
python -m pytest semiconductor_sim -q

echo "== 复现完成：终端校验输出见 results/stageX/terminal.txt，图见 results/stageX/ =="
