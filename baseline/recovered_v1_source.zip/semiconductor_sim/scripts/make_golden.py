# -*- coding: utf-8 -*-
"""
scripts/make_golden.py —— 生成 golden 基准（results/golden/stage{1,2,3}.json）。

用法（仓库根目录 /workspace）：
    python semiconductor_sim/scripts/make_golden.py            # 三个阶段
    python semiconductor_sim/scripts/make_golden.py stage1      # 单个阶段

设计（docs/spec/reproduce_spec.md 第 3 节）：
    - 提取逻辑全部在 tests/golden_helpers.py（与测试共用同一降配配置）；
    - 本脚本只负责"运行 + 落盘"，不重复任何数值逻辑；
    - 基准文件随源码提交：tests/test_golden.py 以 rtol=1e-6 逐键比对，
      任何改变数值的重构/环境迁移都会被发现；
    - 重新生成基准意味着接受新数值：应先确认变化来自预期的代码修改
      （如缺陷修复），并在 CHANGELOG 记录，再运行本脚本。
"""

import os
import sys
import time

# 允许从任意目录调用：把仓库父目录插入 sys.path，统一走包导入
# （与 conftest.py 同一路径，保证 scripts 与 pytest 导入的是同一份模块）
_PARENT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _PARENT not in sys.path:
    sys.path.insert(0, _PARENT)

from semiconductor_sim.common.io import save_json, GOLDEN        # noqa: E402
from semiconductor_sim.tests.golden_helpers import STAGE_NUMBERS  # noqa: E402


def main(argv):
    stages = argv[1:] or ["stage1", "stage2", "stage3"]
    unknown = [s for s in stages if s not in STAGE_NUMBERS]
    if unknown:
        print(f"未知阶段: {unknown}；可选: {list(STAGE_NUMBERS)}")
        return 2
    os.makedirs(GOLDEN, exist_ok=True)
    print(f"golden 目录: {GOLDEN}")
    print(f"比对容差: rtol=1e-6（tests/test_golden.py）\n")
    rc = 0
    for name in stages:
        t0 = time.time()
        print(f"[{name}] 降配运行中 ...")
        numbers = STAGE_NUMBERS[name]()
        path = save_json(name, numbers)
        dt = time.time() - t0
        print(f"[{name}] {len(numbers)} 个标量 -> {path}  ({dt:.1f} s)")
        for k, v in numbers.items():
            print(f"    {k:14s} = {v!r}")
        print()
    print("完成。运行 pytest semiconductor_sim -q 应全绿。")
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv))
