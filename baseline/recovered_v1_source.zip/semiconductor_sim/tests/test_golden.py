# -*- coding: utf-8 -*-
"""
tests/test_golden.py —— golden 基准回归测试（reproduce_spec.md 第 3 节）。

    每个阶段以其降配数字与 results/golden/stageX.json 逐键比对
    （rtol=1e-6，atol=0）。求解链确定性（同平台同库版本）下预期
    逐位一致；任何改变数值的重构、缺陷修复、环境迁移都会在本测试
    暴露——应先解释变化来源，再用 scripts/make_golden.py 重新生成
    基准并在 CHANGELOG 记录。

    golden 文件缺失时跳过（新克隆尚未 make_golden 的场景），
    不视为失败：CI 工作流会在跑 pytest 前先生成基准。
"""

import pytest

from semiconductor_sim.common.io import compare_golden
from semiconductor_sim.tests.golden_helpers import STAGE_NUMBERS

STAGES = ["stage1", "stage2", "stage3"]


@pytest.mark.parametrize("stage", STAGES)
def test_golden_regression(stage):
    """降配数字 vs golden 基准：全部键 rtol=1e-6 内一致。"""
    current = STAGE_NUMBERS[stage]()
    report = compare_golden(stage, current, rtol=1e-6)
    if report is None:
        pytest.skip(f"results/golden/{stage}.json 缺失"
                    "（python semiconductor_sim/scripts/make_golden.py）")
    bad = {k: dev for k, (ok, dev) in report.items() if not ok}
    missing = sorted(set(current) - set(report))
    assert not missing, f"{stage}: golden 缺少键 {missing}"
    assert not bad, (f"{stage}: {len(bad)} 个标量偏离基准（rtol=1e-6）："
                     + ", ".join(f"{k}: rel={dev:.2e}" for k, dev in bad.items()))


@pytest.mark.parametrize("stage", STAGES)
def test_golden_keys_stable(stage):
    """
    提取键集合稳定（防止误删/误增标量而不更新基准）。

    golden 存在时才校验；键集合变化必须显式重新生成基准。
    """
    from semiconductor_sim.common.io import load_json, GOLDEN
    import os
    path = os.path.join(GOLDEN, stage + ".json")
    if not os.path.exists(path):
        pytest.skip(f"results/golden/{stage}.json 缺失")
    ref_keys = set(load_json(stage))
    cur_keys = set(STAGE_NUMBERS[stage]())
    assert cur_keys == ref_keys, (
        f"{stage}: 提取键集合变化 新增={sorted(cur_keys - ref_keys)} "
        f"减少={sorted(ref_keys - cur_keys)}；"
        "请运行 scripts/make_golden.py 重新生成基准")
