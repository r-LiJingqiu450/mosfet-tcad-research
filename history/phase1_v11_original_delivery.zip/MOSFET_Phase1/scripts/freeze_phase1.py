"""Explicitly freeze the NEW revision, never the missing original v1 golden files."""
import argparse,json,sys
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from semiconductor_sim.stage3_mosfet.phase1 import cached_table
from semiconductor_sim.stage3_mosfet.gca import gca_solve,id_vg
from semiconductor_sim.stage3_mosfet.postprocess import extract_vt,extract_ss
p=argparse.ArgumentParser();p.add_argument('--reason',required=True);p.add_argument('--allow-replace',action='store_true');args=p.parse_args()
path=root/'semiconductor_sim/results/golden_phase1.json'
if path.exists() and not args.allow_replace:raise SystemExit('Refusing replacement without --allow-replace')
t,_=cached_table(240,110,'log');vg=np.linspace(0,2,81);lin=id_vg(t,vg,.05)
n=dict(vt_cc=extract_vt(vg,lin)[0],ss=extract_ss(vg,lin),id_lin_2=gca_solve(2,.05,t)['ID'],
       id_sat_2=gca_solve(2,1.5,t)['ID'],ns_source_2=t.solve_vg(2,0)[1])
path.parent.mkdir(exist_ok=True)
path.write_text(json.dumps(dict(version='phase1-1.1',reason=args.reason,
    config=dict(nps=240,npn=110,mode='log',d0_nm=.125,hmax_nm=4),numbers=n),indent=2))
print(path)
