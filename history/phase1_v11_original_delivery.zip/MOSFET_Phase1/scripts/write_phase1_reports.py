"""Build editable Chinese reports solely from computed phase-1 outputs."""
import json,re,hashlib,difflib,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];pkg=root/'semiconductor_sim';out=pkg/'results/phase1'
s=json.loads((out/'phase1_results.json').read_text());r=root/'reports';r.mkdir(exist_ok=True)
th=s['threshold'];b=s['charge_budget']['independent_reference'];ab=s['ablation'][1]
test=(root/'tests_phase1.txt').read_text();test_summary=[v for v in test.splitlines() if 'passed' in v and ' in ' in v][-1] if any('passed' in v and ' in ' in v for v in test.splitlines()) else '测试运行中，详见tests_phase1.txt'
maxerr=100*s['maximum_reference_relative_error'];oldmax=100*s['maximum_coarse_linear_relative_error']
cont='\n'.join(f"| {a['ny']} | {s['baseline']['continuity'][i]['finite_difference']:.6g} | {a['finite_difference']:.6g} | {a['edge_consistency']:.3g} |" for i,a in enumerate(s['continuity']))
ref='\n'.join(f"| {a['vg']:g} | {a['vd']:g} | {a['reference_A']:.8g} | {a['revised_A']:.8g} | {100*a['relative_error']:+.4f}% |" for a in s['current_reference'])
grid='\n'.join(f"| {a['d0_nm']} | {a['hmax_nm']} | {a['nodes']} | {100*a['source_ns_relative_error']:+.5f}% |" for a in s['spatial_refinement'])
report=f'''# MOSFET数值仿真第一阶段修订与验证报告

版本 phase1-1.1；日期 2026年10月26日。此报告由计算结果自动填入数值。

## 1 完成范围与结论

完成阈值分支校正、CLM关闭路径修复、完整GCA积分与直接剖面重建、独立经典Poisson第一积分参考、经典电荷预算，以及Newton停止与表格失败传播的加固。

修订版在固定器件参数和42个验证偏压点上，相对独立参考的最大电流偏差为 **{maxerr:.4f}%**。这是数值实现与约化模型参考的一致性，不是实际MOSFET的实验精度。

新增方法采用标准对数插值与分段解析积分；本阶段不声称算法首创，尚未完成用于SCI投稿的系统新颖性论证、二维DD对标或实验验证。

## 2 原版保护与测试口径

原上传材料保留。baseline/recovered_v1_source.zip保存从Word恢复的原版源码，source_sha256.json记录源文件摘要。未改动S1/S2与common中的物理或数值内核。

前轮原版结果：60项非golden测试通过，6项原始golden测试因缺少JSON跳过。本轮修订版完整测试结果：**{test_summary}**。

原始golden JSON仍然缺失，未冒充补回；results/golden_phase1.json是新版本在独立参考检查后的新冻结回归值。它只检测后续数值变化，不证明物理正确性。冻结命令与正常复现命令分开。

## 3 模型变化必须公开

旧模型：强反型时按任意面密度阈值截断积分，随后施加经验CLM，拼接人工夹断剖面。

修订版默认模型：理想源漏载流子库、经典Boltzmann统计、恒温恒迁移率、垂直准平衡Poisson、从0到完整VD的GCA准费米电流积分。默认不施加CLM。该电流式包含漂移与扩散，未求解完整二维DD。

clm=True只用于显式复现经验模型，其夹断段没有升级为DD物理解。无CLM并不是短沟道效应得到解决；它建立可解释的长沟道基线。

## 4 阈值分解

beta={2.3308649417196002e-4:.10g} A/V²，VD=0.05 V，Ith=0.1 μA。平方律恒流点应取饱和分支，得到VG={th['square_law_cc']:.8f} V，判据偏移{th['criterion_offset_mV']:.4f} mV。

旧表T10采用线性公式得到33.6 mV，但其过驱动小于VD，不满足线性区条件。若保留原版提取值1.04220725 V，原版45.8573 mV差值应改为29.2925+16.5648 mV。

本轮修订版提取值为{th['vt_cc']:.8f} V，总差{th['total_offset_mV']:.4f} mV，分解为{th['criterion_offset_mV']:.4f}+{th['remaining_offset_mV']:.4f} mV。剩余项包括参考模型差别与提取插值效应，不解释为真实物理阈值移动。

## 5 CLM消融

固定VG=2 V、VD=1.5 V。同一240×110线性表用于拆分旧算法的修正项；修订生产表使用400×220对数插值。平方律采用原版提取阈值。

| 方式 | 电流 μA |
|---|---:|
| 平方律 | {ab['square_A']*1e6:.6f} |
| 旧算法关闭CLM，仍截断积分 | {ab['legacy_no_clm_A']*1e6:.6f} |
| 旧算法开启CLM | {ab['legacy_clm_A']*1e6:.6f} |
| 完整积分，同一旧尺寸线性表 | {ab['full_integral_same_table_A']*1e6:.6f} |
| 修订生产配置，无CLM | {ab['revised_production_A']*1e6:.6f} |

旧算法CLM的ΔL/L={ab['delta_L_fraction']:.6f}，其与平方律接近包含显著补偿。关闭CLM的原始代码发生L-y_p=0除法、产生非有限剖面；修订legacy兼容路径仅在ΔL>0时拼接夹断段。

## 6 连续性检查与其证明范围

| 输出网格点数 | 原版+CLM差分波动 | 修订版独立差分波动 | 修订版边积分内部一致性 |
|---:|---:|---:|---:|
{cont}

独立差分采用实际phi_n(y)的数值导数，不将局部电流直接设成端电流。统计掩码仍为Ns>0.2 Ns,max并排除两端各5%，因此这些值不声称夹断/漏端极薄层的点导数均已解析。

边积分一致性来自同一插值表示和累积积分，属于构造内部一致性；机器精度的边通量不能当作独立物理验证。独立差分随加密下降、闭式解析载流子片测试及Poisson第一积分参考共同提供另外的证据。

## 7 独立参考与原先遗漏的亚阈误差

参考不调用有限差分Poisson或查表；对均匀衬底Poisson方程做第一积分，由栅边界求表面势，再对过剩电子密度及准费米势积分。计算域采用半无限中性体近似，并加回1.2 μm体区中性电子背景。非零准费米势的中性体电势与原固定零边界约差3e-14 V（默认掺杂），远小于本轮误差水平；参考并非对所有边界/几何普遍精确。

240×110线性表在同42点矩阵中的最大电流偏差为{oldmax:.4f}%，暴露出原来强反型收敛指标未覆盖的亚阈指数插值误差。标准正值对数插值加400×220表格降低了该误差；本轮不把这项标准数值改动包装成首创。

| VG V | VD V | 独立参考 A | 修订版 A | 相对偏差 |
|---:|---:|---:|---:|---:|
{ref}

quad误差估计只描述积分器估计的积分误差，不包含模型边界误差；详见CSV中单独字段。

## 8 经典电荷预算与空间细化

以独立参考源端解，电荷差的等效栅压分解为：表面势项{1000*b['surface_term_V']:.4f} mV，体电荷项{1000*b['body_term_V']:.4f} mV，合计{1000*b['total_deficit_V']:.4f} mV。恒等式闭合残差{b['closure_V']:.3g} V。

这属于经典统计和静电边界的电荷分配，不是量子限域。源端分解不能替代整个沟道电流积分的解释。

空间细化独立于表格插值：直接解栅边界，h0与hmax一起变化，参考为独立第一积分源端面密度。

| h0 nm | hmax nm | 节点数 | 源端Ns相对误差 |
|---:|---:|---:|---:|
{grid}

这一小规模细化证明该工作点的变化规律，不自动证明任意非均匀网格都有二阶收敛。

## 9 交付与可复现性

运行：python scripts/reproduce_phase1.py。环境实测版本见environment_verified.txt。正常复现不生成golden。结果包含JSON、CSV、NPZ及5组PNG/SVG科学图。

缓存位于.cache，仅保存本代码生成的表格数组；缓存键包含求解器、表格及公共层相关源文件摘要。可删除.cache强制重新建表。发布ZIP不包含缓存。

## 10 尚未完成的研究

本轮仅检验NA=1e16 cm^-3、tox=20 nm、W=L=1 μm、300 K。没有进行跨几何/温度泛化、二维DD源漏结、DIBL、量子限域、场依赖迁移率或AC分析。S1/S2原报告中已指出的理论表述与Bernoulli实现问题保留在后续任务清单，本轮未对共享内核作额外物理修改。

下一阶段应先完成相关方法的新颖性对照与参数泛化，再决定自适应查表或S3到二维DD初值/降阶接口是否足以形成独立论文贡献。
'''
(r/'Phase1_Report.md').write_text(report,encoding='utf-8')
replacement=rf'''# S3独立论文第一轮替换章节

本文档提供可编辑正文草案，数值由本轮运行填入。它不是已经通过新颖性论证的投稿终稿。与原分册相比，默认模型已取消经验CLM，不能继续沿用原图F3—F9和表T5—T13的全部数值。

## 摘要草案

本文建立了采用理想源漏载流子库边界的经典长沟道nMOS沟道约化模型，垂直方向求解准平衡Poisson方程，沿沟道方向计算包含漂移与扩散的准费米势电流积分。通过正值对数插值与分段解析积分，构建400×220截面表，并直接反演累积电荷获得沟道剖面。独立均匀衬底Poisson第一积分及自适应积分参考用于检验数值实现。在所研究器件的42个偏压点上，电流最大相对偏差为{maxerr:.4f}%；饱和工作点的独立差分电流波动随沟道输出网格加密下降，641点时为{s['continuity'][3]['finite_difference']:.4g}。阈值恒流判据与解析阈值的差异由正确的分段平方律与剩余模型差异分别报告。CLM消融表明，旧模型与平方律的较小饱和电流差包含经验沟道缩短造成的补偿。本文结果属于经典约化模型的数值验证，尚不构成实际器件实验验证。

## 模型与边界声明

研究对象是长沟道nMOS的沟道约化域。源漏以理想电子库指定电子准费米势，未显式解析源漏结。空穴准费米势与衬底平衡，电子准费米势在各垂直截面内近似为常数。采用Boltzmann统计与Einstein关系，迁移率为常数。选择该约化域不意味着完整漂移—扩散方程在低电子密度区不存在解。

源端phi_n=0、漏端phi_n=VD。准费米势电流形式已经包含漂移和扩散：

$$J_n=-q\mu_n n\,\partial\varphi_n/\partial y,$$
$$I_D=\frac{{qW\mu_n}}{{L}}\int_0^{{V_D}}N_s(V_G,\varphi_n)\,d\varphi_n.$$

默认不添加经验CLM。模型不包含沿沟道二维电势重分布、短沟道DIBL、量子限域、场依赖迁移率、源漏串联电阻与非准静态响应。因此，无CLM饱和平台不应解释为这些器件物理已经得到正确描述。

## 数值方法

垂直Poisson方程以原非均匀网格离散，采用三对角Newton求解。停止条件同时检查未阻尼Newton修正与按局部Jacobian尺度归一的残差；达到最大回溯次数而未满足接受条件时返回明确失败状态。未收敛截面不能进入有效表格。

在各phi_n列内，以VG反演phi_s，对正电子面密度作对数插值，再在phi_n方向作对数插值。phi_s与总电荷沿用线性插值，故插值后的各物理输出仍须经独立参考检验，不能视为重新求解了Poisson方程。表格越界查询显式报错。

固定VG后，Ns在相邻phi_n节点间表示为分段指数函数。对该插值表示解析积分，并直接反演累积积分构造phi_n(y)，避免固定201点中间剖面及二次重采样。对插值表示的解析精度不等于对连续器件方程的精度。

## 结果与分析

### 阈值判据

在VD=0.05 V与Ith=0.1 μA下，平方律恒流交点位于饱和分支，判据偏移为{th['criterion_offset_mV']:.4f} mV。修订版恒流阈值为{th['vt_cc']:.8f} V；相对解析阈值的总偏移为{th['total_offset_mV']:.4f} mV，其中剩余{th['remaining_offset_mV']:.4f} mV不能直接解释为真实器件阈值移动。

### 经典电荷分解

定义Qn=-qNs、Qb=Qs-Qn。在源端可得：

$$\frac{{q(N_s^{{SL}}-N_s)}}{{C_{{ox}}}}=(\varphi_s-2\psi_F)+\frac{{|Q_b|-|Q_{{b,th}}|}}{{C_{{ox}}}}.$$

VG=2 V时，独立参考中的两项分别为{1000*b['surface_term_V']:.4f}与{1000*b['body_term_V']:.4f} mV。这一电荷预算仅使用经典静电和统计，不归因于量子修正。线性区与饱和区的电流差还取决于整个准费米势积分区间，不能仅凭源端一个数解释。

### CLM消融与守恒

VG=2 V、VD=1.5 V下，旧截断积分无CLM电流为{ab['legacy_no_clm_A']*1e6:.4f} μA，加CLM后为{ab['legacy_clm_A']*1e6:.4f} μA；因此原先与平方律约-4.7%的偏差包含显著补偿。修订生产配置不含CLM，电流为{ab['revised_production_A']*1e6:.4f} μA。电流降低反映模型假设和数值表示变化，不表示数值算法退化。

独立差分检查保留原强沟道掩码。641点时波动为{s['continuity'][3]['finite_difference']:.4g}，小于1e-3目标。边积分内部一致性达到机器精度水平，但该值来自共同构造，不作为独立验证。

### 独立参考

42点偏压矩阵中的最大电流偏差为{maxerr:.4f}%。参考模型通过Poisson第一积分和自适应积分构建，与有限差分/查表路径独立，但采用相同经典材料模型和近似。其结果验证实现，而不验证器件实验预测能力。

## 讨论与局限

原来的饱和连续性误差不能归因于准费米势电流形式遗漏扩散。固定中间剖面、插值与后处理求导会产生不随单一输出网格加密而下降的误差；本轮通过直接反演和独立差分细化检验了这一实现路径。

与平方律对照不是精确解误差测试。表面势未严格钉扎、体电荷变化、反型电荷非线性、阈值定义及经验CLM均可造成差异。未加入的量子限域、迁移率退化或速度饱和不能用来解释两个均未包含这些机制的经典模型之间的现有差值。

本轮没有给出新的物理规律或算法首创证明。后续论文应围绕经过文献检验的具体方法问题，增加参数泛化和二维DD对标，并分别报告数值误差、模型近似误差和实验偏差。

## 结论草案

本轮建立了可复核的经典GCA基线，校正阈值分支和电荷预算解释，修复CLM关闭路径，采用直接累积积分反演消除固定中间剖面引起的误差，并以独立第一积分参考验证电流计算。研究范围内的最大电流偏差为{maxerr:.4f}%；饱和区独立差分检查在641点下满足1e-3目标。以上结论限定于所给经典长沟道约化模型，尚不覆盖真实接触、短沟道、量子及动态器件物理。
'''
(r/'S3_Replacement_Sections.md').write_text(replacement,encoding='utf-8')
(root/'README.md').write_text(f'''# MOSFET 第一阶段修订包

先读 reports/Phase1_Report.md；可编辑的S3正文见 reports/S3_Replacement_Sections.md。

## 运行

需要Python 3.10或以上；建议使用environment_verified.txt中的实测版本。

```bash
python -m pip install -r requirements.txt
python scripts/reproduce_phase1.py
```

该命令运行独立参考、42点对照、CLM消融、连续性与空间细化，并运行全部测试。首次建表耗时依机器而定，可能数分钟。

## 结果

- semiconductor_sim/results/phase1/：原始JSON、CSV、NPZ、5组PNG与SVG图。
- tests_phase1.txt：完整测试日志；本轮为 {test_summary}。
- baseline/：Word恢复的原版源码快照及前轮审计结果。
- semiconductor_sim/results/golden_phase1.json：新修订版的冻结回归值。
- changes.patch：相对恢复原版的源码修改。

原版6项golden由于上传材料缺失JSON而跳过；不会在正常运行时重新生成。新版本golden更新必须显式运行 scripts/freeze_phase1.py --reason 说明 --allow-replace，并保留变更理由。

默认GCA已改成完整积分、无经验CLM；clm=True用于显式旧模型对照。此包不声称已完成二维DD、量子、场依赖迁移率、AC或SCI投稿终稿。
''',encoding='utf-8')
(root/'CHANGELOG.md').write_text('''# phase1-1.1

- 默认完整GCA积分；旧CLM仅显式开启，模型变化单独报告。
- 修复legacy关闭CLM时L-y_p=0的非有限剖面。
- 分段解析积分与直接反演替代固定201点中间剖面。
- 同时保留独立差分电流与边积分内部一致性，不混淆两者。
- 标准正值对数面密度插值；生产表升级400×220。
- Newton联合停止、回溯失败状态、未收敛截面拒绝入表、越界拒绝。
- 增加独立Poisson第一积分、阈值分段逆解、经典电荷预算。
- 新回归基准单独冻结，原缺失golden保持可见。
- 用新驱动及图替换带旧结论硬编码的S3输出；S1/S2和公共内核未作数值改动。
''',encoding='utf-8')
with zipfile.ZipFile(root/'baseline/recovered_v1_source.zip') as z:
    baseline={n:z.read(n).decode('utf-8') for n in z.namelist() if n.endswith('.py')}
patch=[]
for p in sorted(pkg.rglob('*.py')):
    if '__pycache__' in p.parts:continue
    name=str(p.relative_to(root));before=baseline.get(name,'');after=p.read_text()
    if before!=after:patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(root/'changes.patch').write_text(''.join(patch),encoding='utf-8')
print('Reports and source diff written')
