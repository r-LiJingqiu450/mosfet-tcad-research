"""One command: experiment + checks. Does not regenerate any frozen golden."""
import subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,'-m','semiconductor_sim.stage3_mosfet.phase1'],cwd=root,check=True)
with (root/'tests_phase1.txt').open('w',encoding='utf-8') as f:
    r=subprocess.run([sys.executable,'-m','pytest','semiconductor_sim','-q'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
print((root/'tests_phase1.txt').read_text())
raise SystemExit(r.returncode)
