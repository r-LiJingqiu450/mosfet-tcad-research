# MOSFET 第一阶段修订包

先读 reports/Phase1_Report.md；可编辑的S3正文见 reports/S3_Replacement_Sections.md。

## 运行

需要Python 3.10或以上；建议使用environment_verified.txt中的实测版本。

```bash
python -m pip install -r requirements.txt
python scripts/reproduce_phase1.py
```

该命令运行独立参考、42点对照、CLM消融、连续性与空间细化，并运行全部测试。首次建表耗时依机器而定，可能数分钟。

## 结果

- semiconductor_sim/results/phase1/：原始JSON、CSV、NPZ、5组PNG与SVG图。
- tests_phase1.txt：完整测试日志；本轮为 测试运行中，详见tests_phase1.txt。
- baseline/：Word恢复的原版源码快照及前轮审计结果。
- semiconductor_sim/results/golden_phase1.json：新修订版的冻结回归值。
- changes.patch：相对恢复原版的源码修改。

原版6项golden由于上传材料缺失JSON而跳过；不会在正常运行时重新生成。新版本golden更新必须显式运行 scripts/freeze_phase1.py --reason 说明 --allow-replace，并保留变更理由。

默认GCA已改成完整积分、无经验CLM；clm=True用于显式旧模型对照。此包不声称已完成二维DD、量子、场依赖迁移率、AC或SCI投稿终稿。
